window.onload = function() {
    let volunteerInformation = document.getElementById("volunteerInformation");
    let volunteerAccepted = document.getElementById("volunteerAccepted");
    let volunteerDeclined = document.getElementById("volunteerDeclined");
    let btnVolInformation = document.getElementById("btnVolInformation");
    let btnVolAccepted = document.getElementById("btnVolAccepted");
    let btnVolDeclined = document.getElementById("btnVolDeclined");
    
    $(document).ready(function() {
            // Fetch and display all volunteers on page load
            fetchVolunteers('');

            // Add event listener for real-time search
            $('#searchInput').on('input', function() {
                let query = $(this).val();
                fetchVolunteers(query);
            });

            // Function to fetch and display volunteers
            function fetchVolunteers(query) {
                console.log('Fetching volunteers with query:', query); // Debug log
                $.ajax({
                    url: 'search_volunteers.php',
                    type: 'GET',
                    data: { search: query },
                    success: function(response) {
                        console.log('Response received:', response); // Debug log
                        $('#volunteerTableBody').html(response);
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error('AJAX request failed:', textStatus, errorThrown); // Debug log
                    }
                });
            }
        });

    function showSection(section) {
        volunteerInformation.classList.remove("active");
        volunteerAccepted.classList.remove("active");
        volunteerDeclined.classList.remove("active");

        section.classList.add("active");
    }

    btnVolInformation.addEventListener("click", function() {
        showSection(volunteerInformation);
    });

    btnVolAccepted.addEventListener("click", function() {
        showSection(volunteerAccepted);
    });

    btnVolDeclined.addEventListener("click", function() {
        showSection(volunteerDeclined);
    });

    showSection(volunteerInformation); // Default section to show
    
};
