<?php
session_start();
require "config.php";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST["send_otp"])) {
    $usernameAndEmail = $_POST["usernameAndEmail"];
    
    if (!empty($usernameAndEmail)) {
        $result = mysqli_query($conn, "SELECT * FROM account WHERE email = '$usernameAndEmail' OR username = '$usernameAndEmail'");
        $row = mysqli_fetch_assoc($result);
        
        if (mysqli_num_rows($result) > 0) {
            $otp = rand(100000, 999999);
            $_SESSION["otp"] = $otp;
            $_SESSION["otp_id"] = $row["id"];
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'wevoearist2024@gmail.com';
                $mail->Password = 'xnwzeezxbmcauhlm';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;
                // Disable SSL verification (for testing purposes only)
                $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                       'verify_peer_name' => false,
                    'allow_self_signed' => true
                    )
                );
                $mail->setFrom('wevoearist2024@gmail.com', 'wevo');
                $mail->addAddress($row["email"]);
                $mail->isHTML(true);
                $mail->Subject = 'WeVo OTP';
                $mail->Body = 'Your OTP code is ' . $otp;
                $mail->send();
         echo "<script>sweet()</script>";
         echo "OTP sent successfully.";
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            echo "User is not registered.";
        }
    } else {
        echo "Email input is empty. Please provide a valid email.";
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="login.css">
  <script src="jquery-3.3.1.min.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<div id="bg" class="bg-image">
  <div id="container" class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div id= "mainContainer" class="card ">
          <div class="card-header">
            <h1>Login</h1>
          <hr class="my-4">
          
          <div class="card-body ">
            <form id="otpForm" action="verify_login.php" method="POST">
              <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" id="email" name="usernameAndEmail" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="otp">OTP:</label>
                <input type="text" id="otp" name="otp" class="form-control" required>
              </div>
              <div class="form-group">
                <button id="sendOtpBtn" name="send_otp" type="button" class="btn btn-primary btn-block" onclick="sendOtp()">Request OTP</button>
                <div id="timer" class="mt-2"></div>
              </div>
              <button name="submit" type="submit" class="btn btn-primary btn-block custom-button">Login</button>
              <div class="text-center mt-3">
                <a href="registration.php">Register</a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
  function sweet() {
        swal("Good job!", "You clicked the button!", "success");
    }
    
  function sendOtp() {
    let emailInput = $('#email').val().trim();
    if (emailInput === '') {
      alert("Please enter your email.");
      return;
    }

    $.ajax({
      type: 'POST',
      url: '', // Since the PHP script is in the same file
      data: $('#otpForm').serialize() + '&send_otp=1', // Ensure the send_otp is set
      success: function(response) {
        alert(response);
        if (response.includes("successfully")) {
          startTimer(3 * 60);
        }
      },
      error: function(xhr, status, error) {
        alert("Error: " + error);
      }
    });
  }

  function startTimer(duration) {
    var timer = duration, minutes, seconds;
    var display = document.getElementById('timer');
    var sendOtpBtn = document.getElementById('sendOtpBtn');

    sendOtpBtn.disabled = true; // Disable button

    var interval = setInterval(function () {
      minutes = parseInt(timer / 60, 10);
      seconds = parseInt(timer % 60, 10);

      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      display.textContent = minutes + ":" + seconds;

      if (--timer < 0) {
        clearInterval(interval);
        display.textContent = "Time's up!";
        sendOtpBtn.disabled = false; // Re-enable button
      }
    }, 1000);
  }
</script>
</body>
</html>
