<?php
session_start();
include('config.php');

$query = "SELECT * FROM `formList`";
$result = mysqli_query($conn, $query);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);

    $duplicate = mysqli_query($conn, "SELECT * FROM volunteerStatus WHERE volunteerName = '$username' AND email = '$email'");
    if (mysqli_num_rows($duplicate) > 0) {
        echo "<script>alert('This is already processed');</script>";
    } else {
        $status = ($action == "accept") ? "accepted" : "declined";
        $sql = "INSERT INTO volunteerStatus (volunteerName, email, status) VALUES ('$username', '$email', '$status')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Record $status and logged successfully');</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Account</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="ad.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
    <div class="" id="wrapper">
        <!-- Sidebar  -->
        <div id="sidebarContainer" class="">
            <div class="adminTitle">Admin Dashboard</div>
            <div class="sidebarBtnContainer">
                <a href="#" id="btnVolInformation" class="">Volunteer Information</a>
                <a href="#" id="btnVolAccepted" class="">Volunteer Accepted</a>
                <a href="#" id="btnVolDeclined" class="">Volunteer Declined</a>
                <a href="adminLogin.php" id="btnLogout" class="">Logout</a>
            </div>
        </div>

        <!-- Page Content -->
        <div id="page-content-wrapper" class="">
            <!-- Volunteer Information -->
            <div id="volunteerInformation" class="content-section">
                <h3>Volunteer List</h3>
                <!-- Search Form -->
                <form id="searchForm" method="POST" action="">
                    <div class="form-group">
                        <input type="text" id="searchInput" name="search" class="form-control" placeholder="Search for volunteers...">
                    </div>
                    
                <table class="table table-hover table-bordered">
                    <thead class="thead-light">
                        <!-- Your table headers here -->
                    </thead>
                    <tbody id="volunteerTableBody">
                        <!-- Volunteer data will be injected here by JavaScript -->
                    </tbody>
                </table>
            </div>

            <!-- Volunteer Accepted -->
            <div id="volunteerAccepted" class="content-section">
                <h3>Volunteer Accepted</h3>
                <table class="table table-hover table-bordered">
                    <thead class="thead-dark">
                        <tr>
                          <th>Name</th>
                          <th>Email</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include('config.php');
                        $status = "accepted";
                        $query = "SELECT * FROM `volunteerStatus` WHERE status = '$status'";
                        $result = mysqli_query($conn, $query);
                        if (!$result) {
                            die("Query failed: " . mysqli_error($conn));
                        } else {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>
                                        <td>{$row['volunteerName']}</td>
                                        <td>{$row['email']}</td>
                                    </tr>";
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Volunteer Declined -->
            <div id="volunteerDeclined" class="content-section">
                <h3>Volunteer Declined</h3>
                <table class="table table-hover table-bordered">
                    <thead class="thead-dark">
                        <tr class="trDeclined">
                          <th>Name</th>
                          <th>Email </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include('config.php');
                        $status = "declined";
                        $query = "SELECT * FROM `volunteerStatus` WHERE status = '$status'";
                        $result = mysqli_query($conn, $query);
                        if (!$result) {
                            die("Query failed: " . mysqli_error($conn));
                        } else {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>
                                        <td>{$row['volunteerName']}</td>
                                        <td>{$row['email']}</td>
                                    </tr>";
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="admin.js"></script>
</body>
</html>
