<?php
session_start();
define("HOSTNAME","127.0.0.1");
define("USERNAME","root");
define("PASSWORD", "root");
define("DATABASE","userAccount");

$conn = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE);


?>