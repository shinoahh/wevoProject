<?php
require "config.php";

if (isset($_POST["submit"])) {
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirmPassword"];

    $duplicate = mysqli_query($conn, "SELECT * FROM account WHERE email = '$email'");

    if (mysqli_num_rows($duplicate) > 0) {
        echo "<script>alert('Already have an account');</script>";
    } else {
        if ($password == $confirmPassword) {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $query = "INSERT INTO account (email, username, password) VALUES ('$email', '$username', '$hashed_password')";
            if (mysqli_query($conn, $query)) {
                echo "<script>alert('Registration success');</script>";
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            echo "<script>alert('Passwords do not match');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Registration</title>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="register.css">
</head>
<body>
  
 <div id="bg" class="bg-image">
  <div id="container" class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card">
          <div class="card-header">
            <h1>Register</h1>
            <hr class="my-4">
          <div class="card-body">
            <form action="" method="POST" autocomplete="off">
              <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="confirmPassword">Confirm password:</label>
                <input type="password" id="confirmPassword" name="confirmPassword" class="form-control" required>
              </div>
              <button type="submit" name="submit" class="btn btn-primary btn-block">Register</button>
              <div class="text-center mt-3">
                <a href="login.php">Already have an account?</a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>
</html>
